using System;
using Corel.Interop.CorelDRAW;

namespace $safeprojectname$
{
	[System.AddIn.AddIn("My Add-in", Version = "1.0", Publisher = "", Description = "")]
	public partial class Main
	{
		private void Main_Startup(object sender, EventArgs e)
		{

		}

		private void Main_Shutdown(object sender, EventArgs e)
		{

		}

		#region VSTA generated code
		private Application app = null;
		private void InternalStartup()
		{
			this.Startup += new System.EventHandler(Main_Startup);
			this.Shutdown += new System.EventHandler(Main_Shutdown);
			app = (Application)this.Host;
		}
		#endregion

	}
}
