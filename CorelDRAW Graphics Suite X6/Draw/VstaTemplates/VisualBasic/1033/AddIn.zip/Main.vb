<System.AddIn.AddIn("My Add-in", Version:="1.0", Publisher:="", Description:="")> _
Partial Class Main
	WithEvents app As Application

	Private Sub Main_Startup(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Startup
		app = CType(Me.Host, Application)

	End Sub

	Private Sub Main_Shutdown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shutdown

	End Sub

End Class
